import json
import subprocess
from kyt import *

# ID Telegram Admin
ADMIN_ID = "7251232303"

# Fungsi untuk membaca saldo secara real-time
def get_saldo(user_id):
    try:
        with open("saldo.json", "r") as f:
            saldo_data = json.load(f)
        return saldo_data.get(user_id, 0)  # Jika user tidak ada, saldo default = 0
    except FileNotFoundError:
        return 0  # Jika file tidak ditemukan, saldo default = 0

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Hanya admin yang dapat mengakses menu
    if user_id != ADMIN_ID:
        await event.respond("❌ Anda tidak memiliki akses ke menu ini!")
        return

    # Tombol menu dengan tambahan Trojan, SSH, dan VLESS
    inline = [
        [Button.inline(" MENU VMESS ", b"vmess"),
         Button.inline(" MENU TROJAN ", b"trojan")],
        [Button.inline(" MENU SSH ", b"ssh"),
         Button.inline(" MENU VLESS ", b"vless")],
        [Button.inline(" VPS INFO ", b"info"),
         Button.inline(" SETTING ", b"setting")]
    ]

    # Ambil saldo pengguna
    user_saldo = get_saldo(user_id)

    # Ambil informasi sistem
    vm = 'cat /etc/xray/config.json | grep "#vmg" | wc -l'
    tro = 'cat /etc/xray/config.json | grep "#trg" | wc -l'
    vl = 'cat /etc/xray/config.json | grep "#vlg" | wc -l'
    ssh = 'cat /etc/xray/config.json | grep "#ssh" | wc -l'

    vms = subprocess.check_output(vm, shell=True).decode("ascii").strip()
    trojans = subprocess.check_output(tro, shell=True).decode("ascii").strip()
    vless = subprocess.check_output(vl, shell=True).decode("ascii").strip()
    sshs = subprocess.check_output(ssh, shell=True).decode("ascii").strip()

    ipvps = "curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()

    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()

    # Informasi saldo
    saldo_msg = f"💰 **Saldo Anda:** {user_saldo} 💵"
    if user_saldo < 5000:
        saldo_msg += "\n❗ *Saldo Anda kurang dari harga layanan termurah!*"

    # Pesan yang akan ditampilkan
    msg = f"""
🧿───────────────────🧿 
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
๑۞๑ RESELLERSC BY RYYSTORE 
🧿───────────────────🧿
👤 **Hallo {sender.first_name}**
🆔 **ID Telegram:** `{user_id}`
{saldo_msg}
🧿───────────────────🧿
` Kota VPS :` `{city}`
🧿───────────────────🧿
                 **Total Account**
🧿───────────────────🧿
` Xray Vmess  :` `{vms} Account`
` Xray Trojan :` `{trojans} Account`
` Xray Vless  :` `{vless} Account`
` SSH         :` `{sshs} Account`
🧿───────────────────🧿
"""

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)
