import json
import subprocess
from kyt import *

# Load saldo dari file JSON
def load_saldo():
    try:
        with open("saldo.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

saldo = load_saldo()

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" MENU SSH ", b"ssh"),
         Button.inline(" MENU VMESS ", b"vmess")],
        [Button.inline(" MENU VLESS ", b"vless"),
         Button.inline(" MENU TROJAN ", b"trojan")],
        [Button.inline(" NOOBZVPNS ", b"noobz"),
         Button.inline(" TROJAN-GO ", b"trojan-go")],
        [Button.inline(" VPS INFO ", b"info"),
         Button.inline(" SETTING ", b"setting")],
        [Button.inline(" MENU VIP ", b"regis")]
    ]

    sender = await event.get_sender()
    user_id = str(sender.id)
    user_saldo = saldo.get(user_id, 0)

    # Ambil informasi sistem
    sh = 'cat /etc/xray/ssh | grep "###" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = 'cat /etc/xray/config.json | grep "#vmg" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = 'cat /etc/xray/config.json | grep "#vlg" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = 'cat /etc/xray/config.json | grep "#trg" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    noob = 'cat /etc/xray/noob | grep "###" | wc -l'
    noobz = subprocess.check_output(noob, shell=True).decode("ascii")
    tgo = 'cat /etc/trojan-go/trgo | grep "###" | wc -l'
    trgo = subprocess.check_output(tgo, shell=True).decode("ascii")
    sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = "curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")

    # Informasi saldo
    saldo_msg = f"💰 **Saldo Anda:** {user_saldo} 💵"
    if user_saldo < 5000:
        saldo_msg += "\n❗ *Saldo Anda kurang dari harga layanan termurah!*"

    msg = f"""
🧿───────────────────🧿 
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
๑۞๑ AUTOSCRIPT BY RYYSTORE 
🧿───────────────────🧿
👤 **Hallo {sender.first_name}**  
{saldo_msg}
🧿───────────────────🧿
` Ip Vps:` `{ipsaya.strip()}`
` City  :` `{city.strip()}`
🧿───────────────────🧿
                 **Total Account**
🧿───────────────────🧿
` Ssh Ovpn    :` `{ssh.strip()} Account`
` Xray Vmess  :` `{vms.strip()} Account`
` Xray Vless  :` `{vls.strip()} Account`
` Xray Trojan :` `{trj.strip()} Account`
` Noobzvpns   :` `{noobz.strip()} Account`
` Trojan-Go   :` `{trgo.strip()} Account`
🧿───────────────────🧿
"""

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)
