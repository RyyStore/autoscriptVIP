import json
import subprocess
from kyt import *

# Fungsi untuk membaca saldo secara real-time
def get_saldo(user_id):
    try:
        with open("saldo.json", "r") as f:
            saldo_data = json.load(f)
        return saldo_data.get(user_id, 0)  # Jika user tidak ada, saldo default = 0
    except FileNotFoundError:
        return 0  # Jika file tidak ditemukan, saldo default = 0

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Tombol menu hanya VMESS, VPS INFO, dan SETTING
    inline = [
        [Button.inline(" MENU VMESS ", b"vmess")],
        [Button.inline(" VPS INFO ", b"info"),
         Button.inline(" SETTING ", b"setting")]
    ]

    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # Ambil saldo terbaru secara real-time
    user_saldo = get_saldo(user_id)

    # Ambil informasi sistem
    vm = 'cat /etc/xray/config.json | grep "#vmg" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")

    ipvps = "curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")

    # Informasi saldo pengguna
    saldo_msg = f"💰 **Saldo Anda:** {user_saldo} 💵"
    if user_saldo < 5000:
        saldo_msg += "\n❗ *Saldo Anda kurang dari harga layanan termurah!*"

    # Pesan yang akan ditampilkan
    msg = f"""
🧿───────────────────🧿 
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
๑۞๑ RESELLERSC BY RYYSTORE 
🧿───────────────────🧿
👤 **Hallo {sender.first_name}**  
{saldo_msg}
🧿───────────────────🧿
` Kota VPS :` `{city.strip()}`
🧿───────────────────🧿
                 **Total Account**
🧿───────────────────🧿
` Xray Vmess  :` `{vms.strip()} Account`
🧿───────────────────🧿
"""

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)
