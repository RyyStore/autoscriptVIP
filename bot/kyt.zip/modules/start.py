import json
import subprocess
from kyt import *

# ID Telegram Admin
ADMIN_ID = "7251232303"

# Fungsi untuk membaca saldo secara real-time
def get_saldo(user_id):
    try:
        with open("saldo.json", "r") as f:
            saldo_data = json.load(f)
        return saldo_data.get(user_id, 0)  # Default saldo 0 jika tidak ada
    except (FileNotFoundError, json.JSONDecodeError):
        return 0  # Jika file tidak ditemukan atau rusak, saldo = 0

# Fungsi untuk menyimpan saldo ke file secara real-time
def save_saldo(user_id, jumlah):
    saldo_data = {}

    try:
        with open("saldo.json", "r") as f:
            saldo_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    saldo_data[user_id] = saldo_data.get(user_id, 0) + jumlah

    with open("saldo.json", "w") as f:
        json.dump(saldo_data, f, indent=4)

    return saldo_data[user_id]  # Kembalikan saldo terbaru setelah update

@bot.on(events.NewMessage(pattern=r"/start$"))
async def start(event):
    await menu(event)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Ambil saldo real-time
    user_saldo = get_saldo(user_id)

    # Ambil informasi jumlah akun VMESS
    vm = 'cat /etc/xray/config.json | grep "#vmg" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii").strip()

    # Ambil informasi kota VPS
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()

    saldo_msg = f"💰 **Saldo Anda:** {user_saldo} 💵"
    if user_saldo < 5000:
        saldo_msg += "\n❗ *Saldo Anda kurang dari harga layanan termurah!*"

    msg = f"""
🧿───────────────────🧿 
👤 **Hallo {sender.first_name}**  
🆔 **ID Telegram:** `{user_id}`
{saldo_msg}
🧿───────────────────🧿
` Kota VPS :` `{city}`
🧿───────────────────🧿
                 **Total Account**
🧿───────────────────🧿
` Xray Vmess  :` `{vms} Account`
🧿───────────────────🧿
"""

    inline = [
        [Button.inline(" MENU VMESS ", b"vmess")],
        [Button.inline(" VPS INFO ", b"info"),
         Button.inline(" SETTING ", b"setting")]
    ]

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)

# Cek saldo pengguna sendiri (real-time)
@bot.on(events.NewMessage(pattern=r"/saldo"))
async def cek_saldo(event):
    user_id = str(event.sender_id)
    saldo_user = get_saldo(user_id)
    await event.respond(f"💰 Saldo Anda: {saldo_user} 💵")

# Cek saldo pengguna lain (hanya admin)
@bot.on(events.NewMessage(pattern=r"/ceksaldo (\d+)"))
async def cek_saldo_user(event):
    if str(event.sender_id) != ADMIN_ID:
        await event.respond("❌ Anda tidak memiliki izin untuk mengecek saldo pengguna lain!")
        return

    user_id = event.pattern_match.group(1)
    saldo_user = get_saldo(user_id)

    await event.respond(f"💰 Saldo ID `{user_id}`: {saldo_user} 💵")

# Admin bisa menambahkan saldo (real-time)
@bot.on(events.NewMessage(pattern=r"/topup (\d+) (\d+)"))
async def topup_saldo(event):
    if str(event.sender_id) != ADMIN_ID:
        await event.respond("❌ Anda tidak memiliki izin untuk menambahkan saldo!")
        return

    jumlah = int(event.pattern_match.group(1))
    user_id = event.pattern_match.group(2)

    saldo_terbaru = save_saldo(user_id, jumlah)

    await event.respond(f"✅ Topup {jumlah} berhasil untuk ID {user_id}! Saldo sekarang: {saldo_terbaru} 💵")

    try:
        await bot.send_message(user_id, f"✅ Saldo Anda telah di-topup sebesar {jumlah} 💵! Saldo sekarang: {saldo_terbaru} 💵")
    except:
        pass

# Admin bisa mengurangi saldo pengguna lain (real-time)
@bot.on(events.NewMessage(pattern=r"/potongsaldo (\d+) (\d+)"))
async def potong_saldo(event):
    if str(event.sender_id) != ADMIN_ID:
        await event.respond("❌ Anda tidak memiliki izin untuk mengurangi saldo!")
        return

    jumlah = int(event.pattern_match.group(1))
    user_id = event.pattern_match.group(2)

    saldo_sekarang = get_saldo(user_id)
    
    if saldo_sekarang < jumlah:
        await event.respond(f"❌ Saldo ID `{user_id}` tidak cukup untuk dikurangi {jumlah} 💵!")
        return

    saldo_terbaru = save_saldo(user_id, -jumlah)

    await event.respond(f"✅ Saldo ID {user_id} berhasil dikurangi {jumlah}! Saldo sekarang: {saldo_terbaru} 💵")

    try:
        await bot.send_message(user_id, f"❗ Saldo Anda telah dikurangi sebesar {jumlah} 💵. Saldo sekarang: {saldo_terbaru} 💵")
    except:
        pass
