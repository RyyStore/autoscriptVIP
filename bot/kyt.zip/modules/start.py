import json
import subprocess
from kyt import *

# ID Telegram Admin
ADMIN_ID = "7251232303"

# Fungsi untuk membaca saldo secara real-time
def get_saldo(user_id):
    try:
        with open("saldo.json", "r") as f:
            saldo_data = json.load(f)
        return saldo_data.get(user_id, 0)  # Jika user tidak ada, saldo default = 0
    except FileNotFoundError:
        return 0  # Jika file tidak ditemukan, saldo default = 0

# Fungsi untuk menyimpan saldo ke file
def save_saldo(saldo_data):
    with open("saldo.json", "w") as f:
        json.dump(saldo_data, f)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Tombol menu hanya untuk VMESS, VPS INFO, dan SETTING
    inline = [
        [Button.inline(" MENU VMESS ", b"vmess")],
        [Button.inline(" VPS INFO ", b"info"),
         Button.inline(" SETTING ", b"setting")]
    ]

    sender = await event.get_sender()
    user_id = str(sender.id)
    
    # Ambil saldo terbaru secara real-time
    user_saldo = get_saldo(user_id)

    # Ambil informasi jumlah akun VMESS
    vm = 'cat /etc/xray/config.json | grep "#vmg" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii").strip()

    # Ambil informasi IP VPS dan Kota
    ipvps = "curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()

    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii").strip()

    # Informasi saldo pengguna
    saldo_msg = f"💰 **Saldo Anda:** {user_saldo} 💵"
    if user_saldo < 5000:
        saldo_msg += "\n❗ *Saldo Anda kurang dari harga layanan termurah!*"

    # Pesan yang akan ditampilkan
    msg = f"""
🧿───────────────────🧿 
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
๑۞๑ AUTOSCRIPT BY RYYSTORE 
🧿───────────────────🧿
👤 **Hallo {sender.first_name}**  
{saldo_msg}
🧿───────────────────🧿
` IP VPS   :` `{ipsaya}`
` Kota VPS :` `{city}`
🧿───────────────────🧿
                 **Total Account**
🧿───────────────────🧿
` Xray Vmess  :` `{vms} Account`
🧿───────────────────🧿
"""

    x = await event.edit(msg, buttons=inline)
    if not x:
        await event.reply(msg, buttons=inline)

# Perintah untuk mengecek saldo secara real-time
@bot.on(events.NewMessage(pattern=r"/saldo"))
async def cek_saldo(event):
    user_id = str(event.sender_id)
    saldo_user = get_saldo(user_id)
    await event.respond(f"💰 Saldo Anda: {saldo_user} 💵")

# Perintah untuk topup saldo (hanya bisa dilakukan oleh admin)
@bot.on(events.NewMessage(pattern=r"/topup (\d+) (\d+)"))
async def topup_saldo(event):
    admin_id = str(event.sender_id)
    
    # Cek apakah pengirim adalah admin
    if admin_id != ADMIN_ID:
        await event.respond("❌ Anda tidak memiliki izin untuk menambahkan saldo!")
        return
    
    jumlah = int(event.pattern_match.group(1))
    user_id = event.pattern_match.group(2)

    saldo_data = {}
    try:
        with open("saldo.json", "r") as f:
            saldo_data = json.load(f)
    except FileNotFoundError:
        pass

    saldo_data[user_id] = saldo_data.get(user_id, 0) + jumlah
    save_saldo(saldo_data)
    
    # Kirim pesan ke admin yang melakukan topup
    await event.respond(f"✅ Topup {jumlah} berhasil untuk ID {user_id}! Saldo sekarang: {saldo_data[user_id]} 💵")
    
    # Kirim pesan ke pengguna yang menerima topup
    try:
        await bot.send_message(user_id, f"✅ Saldo Anda telah di-topup sebesar {jumlah} 💵! Saldo sekarang: {saldo_data[user_id]} 💵")
    except:
        pass  # Jika user tidak bisa menerima pesan, abaikan error
