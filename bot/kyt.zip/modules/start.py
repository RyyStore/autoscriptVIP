import json
import subprocess
from kyt import *

# Daftar Admin yang bisa menambahkan saldo (Ganti dengan ID Telegram admin)
ADMIN_IDS = ["7251232303", "987654321"]  # Masukkan ID admin di sini

# Load saldo dari file JSON
def load_saldo():
    try:
        with open("saldo.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Simpan saldo ke file JSON
def save_saldo(saldo):
    with open("saldo.json", "w") as f:
        json.dump(saldo, f)

saldo = load_saldo()

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("PANEL CREATE ACCOUNT", b"menu")],
        [Button.url("GROUP", "https://t.me/@@RyyStorevp1"),
         Button.url("ORDER", "https://t.me/@RyyStorevp1")]
    ]
    
    # Ambil informasi sistem
    sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
    ssh = subprocess.check_output(sh, shell=True).decode("ascii")
    vm = 'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
    vms = subprocess.check_output(vm, shell=True).decode("ascii")
    vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
    vls = subprocess.check_output(vl, shell=True).decode("ascii")
    tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
    trj = subprocess.check_output(tr, shell=True).decode("ascii")
    sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
    namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
    ipvps = "curl -s ipv4.icanhazip.com"
    ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
    city = subprocess.check_output("cat /etc/xray/city", shell=True).decode("ascii")

    msg = f"""
🧿───────────────────🧿
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
█░░║║║╠─║─║─║║║║║╠─░░█
█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
๑۞๑ @RyyStorevp1
🧿───────────────────🧿
`IP    :` {ipsaya.strip()}
`Domain:` {DOMAIN}
`City  :` {city.strip()}
`OS    :` {namaos.strip().replace('"', '')}
@RyyStorevp1
🧿───────────────────🧿
"""
    await event.respond(msg, buttons=inline)

# Perintah untuk mengecek saldo
@bot.on(events.NewMessage(pattern=r"/saldo"))
async def cek_saldo(event):
    user_id = str(event.sender_id)
    saldo_user = saldo.get(user_id, 0)
    await event.respond(f"💰 Saldo Anda: {saldo_user} 💵")

# Perintah untuk topup saldo (hanya bisa dilakukan oleh admin)
@bot.on(events.NewMessage(pattern=r"/topup (\d+) (\d+)"))
async def topup_saldo(event):
    admin_id = str(event.sender_id)
    
    # Cek apakah pengirim adalah admin
    if admin_id not in ADMIN_IDS:
        await event.respond("❌ Anda tidak memiliki izin untuk menambahkan saldo!")
        return
    
    jumlah = int(event.pattern_match.group(1))
    user_id = event.pattern_match.group(2)

    saldo[user_id] = saldo.get(user_id, 0) + jumlah
    save_saldo(saldo)
    
    await event.respond(f"✅ Topup {jumlah} berhasil untuk ID {user_id}! Saldo sekarang: {saldo[user_id]} 💵")

# Perintah untuk membeli akun VPN menggunakan saldo
@bot.on(events.NewMessage(pattern=r"/beli (ssh|vmess|vless|trojan|shadowsocks)"))
async def beli_layanan(event):
    user_id = str(event.sender_id)
    produk = event.pattern_match.group(1)
    harga = {"ssh": 5000, "vmess": 7000, "vless": 7000, "trojan": 8000, "shadowsocks": 8000}

    if saldo.get(user_id, 0) < harga[produk]:
        await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
    else:
        saldo[user_id] -= harga[produk]
        save_saldo(saldo)
        await event.respond(f"✅ Pembelian {produk.upper()} berhasil! Saldo tersisa: {saldo[user_id]} 💵")

