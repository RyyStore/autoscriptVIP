from kyt import *
import json
import subprocess
import requests

# ID Admin (ganti dengan ID pengguna admin yang sebenarnya)
ADMIN_ID = 7251232303  # Ganti dengan ID admin yang sesuai

# Fungsi untuk memeriksa apakah pengirim adalah admin
def is_admin(sender_id):
    return sender_id == ADMIN_ID

# Load saldo dari file JSON
def load_saldo():
    try:
        with open("saldo.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Simpan saldo ke file JSON
def save_saldo(saldo):
    with open("saldo.json", "w") as f:
        json.dump(saldo, f)

saldo = load_saldo()

# Harga per hari
HARGA_PER_HARI = 200
HARGA_30_HARI = 6000

# Fungsi untuk menghitung harga berdasarkan durasi
def hitung_harga(durasi_hari):
    if durasi_hari == 1:
        return HARGA_PER_HARI
    elif durasi_hari == 30:
        return HARGA_30_HARI
    else:
        return HARGA_PER_HARI * durasi_hari

# Create VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        user_id = str(event.sender_id)  # ID user yang meminta akun
        user_saldo = saldo.get(user_id, 0)

        async with bot.conversation(event.chat_id) as user:
            await event.edit(f"""
**Input UserName :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            user = (await user).raw_text

        if user == "/cancel":
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        async with bot.conversation(event.chat_id) as exp:
            await event.respond(f"""
**Input Your Expired (days) :**
/cancel Untuk Kembali
""")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            exp = (await exp).raw_text

        try:
            durasi_hari = int(exp)
            harga = hitung_harga(durasi_hari)

            if user_saldo < harga:
                await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
                return

            # Proses pembuatan akun VMess
            limit_ip = "2"
            quota = "200"
            cmd = f'printf "%s\n" "1" "{user}" "{durasi_hari}" "{limit_ip}" "{quota}" "{event.sender_id}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

            # Potong saldo pengguna
            saldo[user_id] -= harga
            save_saldo(saldo)

            await event.respond(f"""
✅ Akun VMess berhasil dibuat!
💰 Saldo tersisa: {saldo[user_id]} 💵
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

        except ValueError:
            await event.respond("❌ Input tidak valid! Pastikan Anda memasukkan angka untuk durasi hari.")

    await create_vmess_(event)
