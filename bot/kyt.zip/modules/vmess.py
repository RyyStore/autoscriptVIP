from kyt import *
import json
import subprocess
from datetime import datetime
from telethon import events, Button

ADMIN_IDS = ["7251232303"]  # Daftar ID Admin
SALDO_FILE = "saldo.json"
TRIAL_FILE = "trial.json"

def load_saldo():
    try:
        with open(SALDO_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_saldo(saldo):
    with open(SALDO_FILE, "w") as f:
        json.dump(saldo, f)

def load_trial():
    try:
        with open(TRIAL_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_trial(data):
    with open(TRIAL_FILE, "w") as f:
        json.dump(data, f)

def reset_trial():
    trial_data = load_trial()
    today = datetime.now().strftime("%Y-%m-%d")
    if "last_reset" not in trial_data or trial_data["last_reset"] != today:
        trial_data = {"last_reset": today}
        save_trial(trial_data)

saldo = load_saldo()
HARGA_PER_HARI = 200
HARGA_30_HARI = 6000

def hitung_harga(durasi_hari):
    if durasi_hari == 1:
        return HARGA_PER_HARI
    elif durasi_hari == 30:
        return HARGA_30_HARI
    else:
        return HARGA_PER_HARI * durasi_hari

@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(sender.id)

    reset_trial()
    trial_data = load_trial()
    trial_count = trial_data.get(user_id, 0)

    if user_id not in ADMIN_IDS and trial_count >= 7:
        await bot.send_message(chat, "❌ Anda sudah mencapai batas maksimal 7 trial per hari!")
        return

    duration = 30
    cmd = f'printf "%s\n" "2" "{duration}" | m-vmess | sleep 2 | exit'
    result = subprocess.check_output(cmd, shell=True).decode("utf-8")

    if user_id not in ADMIN_IDS:
        trial_data[user_id] = trial_count + 1
        save_trial(trial_data)

    await bot.send_message(
        chat,
        f"✅ Trial VMess berhasil dibuat!\n🕒 Durasi: {duration} menit\n📌 Anda sudah menggunakan {trial_data.get(user_id, 0)}/7 trial hari ini."
        if user_id not in ADMIN_IDS
        else "✅ Trial VMess berhasil dibuat!\n🕒 Durasi: 30 menit\n👑 Admin dapat membuat trial tanpa batas."
    )

@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        user_id = str(sender.id)

        async with bot.conversation(chat) as conv:
            await event.edit("**Input UserName :**\n/cancel Untuk Kembali")
            user = (await conv.get_response()).raw_text

        if user == "/cancel":
            await bot.send_message(chat, "**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        async with bot.conversation(chat) as conv:
            await bot.send_message(chat, "**Input Your Expired (day) :**")
            exp = (await conv.get_response()).raw_text

        try:
            exp = int(exp)
        except ValueError:
            await bot.send_message(chat, "❌ Input tidak valid! Pastikan Anda memasukkan angka untuk masa aktif.")
            return

        # Set default limit IP = 2 dan Quota = 200GB jika tidak ada input dari pengguna
        limit_ip = 2
        quota = 200

        saldo = load_saldo()
        user_saldo = saldo.get(user_id, 0)
        harga = hitung_harga(exp)

        if user_saldo < harga:
            await bot.send_message(chat, "❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
            return

        # Create VMess
        cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{limit_ip}" "{quota}" | m-vmess | sleep 2 | exit'
        result = subprocess.check_output(cmd, shell=True).decode("utf-8")

        saldo[user_id] -= harga
        save_saldo(saldo)

        await bot.send_message(chat, f"""
✅ **Akun VMess berhasil dibuat!**
📌 **Username:** {user}
🕒 **Masa Aktif:** {exp} Hari
🔢 **Limit IP:** {limit_ip} IP
📊 **Quota:** {quota} GB
💰 **Saldo tersisa:** {saldo[user_id]} 💵
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
    user_id = str(event.sender_id)

    if user_id not in ADMIN_IDS:
        await event.respond("❌ Anda tidak memiliki akses untuk menghapus akun VMess!")
        return

    async def delete_vmess_(event):
        async with bot.conversation(event.chat_id) as conv:
            cmd2 = f"cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")

            await event.edit(f"""
**LIST ALL USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
            user = (await conv.get_response()).raw_text

        if user == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        cmd = f'printf "%s\n" "4" "{user}" | m-vmess | sleep 2 | exit'
        subprocess.check_output(cmd, shell=True)

        await event.respond("✅ Akun VMess berhasil dihapus!", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    await delete_vmess_(event)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    user_id = str(event.sender_id)
    is_admin = user_id in ADMIN_IDS

    inline = [
        [Button.inline(" Trial ", "trial7-vmess"),
         Button.inline(" Create ", "create7-vmess")]
    ]

    if is_admin:
        inline.append([Button.inline(" Delete ", "delete7-vmess")])

    inline.append([Button.inline("‹ BACK ›", "menu")])

    msg = f"""
🧿 PANEL VMESS
**› Trial** : **7x per hari**
**› Create** : **Berbayar**
{"**› Delete** : **Admin Only**" if is_admin else ""}
"""
    await event.edit(msg, buttons=inline)
