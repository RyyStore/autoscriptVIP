from kyt import *
import json
import subprocess
from datetime import datetime

ADMIN_IDS = ["7251232303"]  # Daftar ID Admin
SALDO_FILE = "saldo.json"
TRIAL_FILE = "trial.json"
VMESS_FILE = "vmess.json"

# Load & simpan data
def load_json(file):
    try:
        with open(file, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_json(file, data):
    with open(file, "w") as f:
        json.dump(data, f, indent=4)

# Reset trial harian
def reset_trial():
    trial_data = load_json(TRIAL_FILE)
    today = datetime.now().strftime("%Y-%m-%d")
    if trial_data.get("last_reset") != today:
        trial_data = {"last_reset": today}
        save_json(TRIAL_FILE, trial_data)

HARGA_PER_HARI = 200
HARGA_30_HARI = 6000

def hitung_harga(durasi_hari):
    return HARGA_PER_HARI * durasi_hari if durasi_hari != 30 else HARGA_30_HARI

@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    user_id = str(event.sender_id)
    reset_trial()
    trial_data = load_json(TRIAL_FILE)

    user_trial = trial_data.get(user_id, {"count": 0, "accounts": []})
    if user_id not in ADMIN_IDS and user_trial["count"] >= 7:
        await event.respond("❌ Anda sudah mencapai batas maksimal 7 trial per hari!")
        return

    duration = 30
    cmd = f'printf "%s\n" "2" "{duration}" | m-vmess | sleep 2 | exit'
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8").strip()
    except subprocess.CalledProcessError as e:
        await bot.send_message(user_id, f"❌ Gagal membuat trial:\n{e.output.decode()}")
        return

    user_trial["count"] += 1
    user_trial["accounts"].append(output)
    trial_data[user_id] = user_trial
    save_json(TRIAL_FILE, trial_data)

    await bot.send_message(user_id, f"✅ Trial VMess berhasil dibuat!\n🕒 Durasi: {duration} menit\n📌 Anda sudah menggunakan {user_trial['count']}/7 trial hari ini.\n\n🔗 Detail akun:\n{output}")
    await event.respond("✅ Trial VMess berhasil dibuat! Detail akun telah dikirim ke private chat Anda.")

@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    user_id = str(event.sender_id)
    saldo = load_json(SALDO_FILE)
    user_saldo = saldo.get(user_id, 0)
    vmess_data = load_json(VMESS_FILE)

    async with bot.conversation(event.sender_id) as user:
        await event.respond("**Masukkan Username:**\n/cancel untuk kembali")
        user = await user.get_response()
        username = user.raw_text

    if username == "/cancel":
        await event.respond("❌ Proses dibatalkan.")
        return

    async with bot.conversation(event.sender_id) as exp:
        await event.respond("**Masukkan Durasi (hari):**\n/cancel untuk kembali")
        exp = await exp.get_response()
        try:
            durasi_hari = int(exp.raw_text)
        except ValueError:
            await event.respond("❌ Durasi harus berupa angka!")
            return

    harga = hitung_harga(durasi_hari)
    if user_saldo < harga:
        await bot.send_message(user_id, "❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
        return

    cmd = f'printf "%s\n" "1" "{username}" "{durasi_hari}" "2" "200" | m-vmess | sleep 2 | exit'
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8").strip()
    except subprocess.CalledProcessError as e:
        await bot.send_message(user_id, f"❌ Gagal membuat akun VMess:\n{e.output.decode()}")
        return

    saldo[user_id] -= harga
    save_json(SALDO_FILE, saldo)

    if user_id not in vmess_data:
        vmess_data[user_id] = []
    vmess_data[user_id].append(output)
    save_json(VMESS_FILE, vmess_data)

    await bot.send_message(user_id, f"✅ Akun VMess berhasil dibuat!\n🕒 Durasi: {durasi_hari} hari\n💰 Saldo tersisa: {saldo[user_id]} 💵\n\n🔗 Detail akun:\n{output}")
    await event.respond("✅ Akun VMess berhasil dibuat! Detail akun telah dikirim ke private chat Anda.")

@bot.on(events.CallbackQuery(data=b'list-trial'))
async def list_trial(event):
    user_id = str(event.sender_id)
    trial_data = load_json(TRIAL_FILE).get(user_id, {"accounts": []})
    accounts = trial_data["accounts"]

    if not accounts:
        await event.respond("❌ Anda belum memiliki akun trial.")
        return

    msg = "📜 **Daftar Akun Trial Anda:**\n\n" + "\n".join(f"{i+1}. {acc}" for i, acc in enumerate(accounts))
    await bot.send_message(user_id, msg)

@bot.on(events.CallbackQuery(data=b'list-vmess'))
async def list_vmess(event):
    user_id = str(event.sender_id)
    vmess_data = load_json(VMESS_FILE).get(user_id, [])

    if not vmess_data:
        await event.respond("❌ Anda belum memiliki akun VMess.")
        return

    msg = "📜 **Daftar Akun VMess Anda:**\n\n" + "\n".join(f"{i+1}. {acc}" for i, acc in enumerate(vmess_data))
    await bot.send_message(user_id, msg)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    inline = [
        [Button.inline("Trial", "trial7-vmess"), Button.inline("List Trial", "list-trial")],
        [Button.inline("Create", "create7-vmess"), Button.inline("List VMess", "list-vmess")],
        [Button.inline("‹ BACK ›", "menu")]
    ]
    await event.edit("🔹 **Menu VMess** 🔹", buttons=inline)
