from kyt import *

# Fungsi untuk mengurangi saldo user
def kurangi_saldo(user_id, jumlah):
    saldo_sekarang = get_saldo(user_id)
    if saldo_sekarang >= jumlah:
        update_saldo(user_id, saldo_sekarang - jumlah)
        return True
    return False

# delete
@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f"cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '"
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**LIST ALL USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        if user == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            cmd = f'printf "%s\n" "4" "{user}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# create
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"**Input UserName :**\n/cancel Untuk Kembali")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        if user == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return
        
        async with bot.conversation(chat) as exp:
            await event.respond(f"**Input Your Expired (day) :**")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        # Set default untuk Limit IP dan Quota User
        limit_ip = 2  # Default limit IP
        quota_user = 200  # Default quota dalam GB

        # Cek saldo dan kurangi jika cukup
        harga_akun = 6000  # Harga akun reguler
        if kurangi_saldo(sender.id, harga_akun):
            cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{limit_ip}" "{quota_user}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"**» SUCCESS CREATE VMESS**\nAkun berhasil dibuat dan saldo dikurangi sebesar {harga_akun} rupiah.\n\n**Detail Akun:**\n- **Username:** {user}\n- **Expired:** {exp} hari\n- **Limit IP:** {limit_ip}\n- **Quota:** {quota_user}GB", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            await event.respond("**Saldo tidak cukup!**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# trial
@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.edit(f"**Input Your Minutes (Hanya Angka) :**\n/cancel Untuk Kembali")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        if exp == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            cmd = f'printf "%s\n" {2} "{exp}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

# cek
@bot.on(events.CallbackQuery(data=b'cek7-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bot-cek-ws'.strip()
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.edit(f"**VMESS USER ONLINE**\n{z}", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline(" UNLOCK LOGIN ", "loginip7-vmess"),
             Button.inline(" UNLOCK QUOTA ", "logingb7-vmess")],
            [Button.inline("‹ Back ›", "vmess")]
        ]
        await event.edit(buttons=inline)
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline(" Trial ", "trial7-vmess"),
             Button.inline(" Create ", "create7-vmess"),
             Button.inline(" Login ", "cek7-vmess")],
            [Button.inline(" Delete ", "delete7-vmess"),
             Button.inline(" Renew ", "renew7-vmess")],
            [Button.inline(" Change Limit ", "limit7-vmess"),
             Button.inline(" Restore ", "restore7-vmess")],
            [Button.inline(" Multi Login ", "login7-vmess"),
             Button.inline("‹ Back ›", "menu")]
        ]
        await event.edit(buttons=inline)
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await vmess_(event)
    else:
        await event.answer("Akses Ditolak", alert=True)
