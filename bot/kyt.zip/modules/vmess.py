from kyt import *
import json
import subprocess
import requests

# ID Admin (ganti dengan ID pengguna admin yang sebenarnya)
ADMIN_ID = 7251232303  # Ganti dengan ID admin yang sesuai

# Fungsi untuk memeriksa apakah pengirim adalah admin
def is_admin(sender_id):
    return sender_id == ADMIN_ID

# Load saldo dari file JSON
def load_saldo():
    try:
        with open("saldo.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Simpan saldo ke file JSON
def save_saldo(saldo):
    with open("saldo.json", "w") as f:
        json.dump(saldo, f)

saldo = load_saldo()

# Harga per hari
HARGA_PER_HARI = 200
HARGA_30_HARI = 6000

# Fungsi untuk menghitung harga berdasarkan durasi
def hitung_harga(durasi_hari):
    if durasi_hari == 1:
        return HARGA_PER_HARI
    elif durasi_hari == 30:
        return HARGA_30_HARI
    else:
        return HARGA_PER_HARI * durasi_hari

# VMESS Main Menu
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    sender_id = event.sender_id
    inline = [
        [Button.inline(" Trial ", b"trial7-vmess"),
         Button.inline(" Create ", b"create7-vmess"),
         Button.inline(" Login ", b"cek7-vmess")]
    ]
    if is_admin(sender_id):  # Cek apakah pengirim adalah admin
        inline.append([
            Button.inline(" Delete ", b"delete7-vmess"),
            Button.inline(" Unlock ", b"login7-vmess"),
            Button.inline(" Limit ", b"limit7-vmess"),
            Button.inline(" Renew", b"renew7-vmess"),
            Button.inline(" Restore ", b"restore7-vmess"),
            Button.inline(" Akun ", b"akun7-vmess")
        ])
    inline.append([Button.inline("‹ BACK ›", b"menu")])

    # Mendapatkan informasi tentang server
    try:
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        vm = f'cat /etc/xray/config.json | grep "#vmg" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii").strip()
    except Exception as e:
        await event.answer("Terjadi kesalahan saat mengambil data server!", alert=True)
        return

    msg = f"""
🧿───────────────────🧿
          **PANEL MENU VMESS**
🧿──────────────────
─🧿
` Total   :` `{vms}` __account__
` Host    :` `{DOMAIN}`
` ISP     :` `{z.get("isp", "Unknown ISP")}`
` Country :` `{z.get("country", "Unknown Country")}`
🧿───────────────────🧿
"""
    await event.edit(msg, buttons=inline)

# Create VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    sender_id = str(event.sender_id)  # ID user yang meminta akun
    user_saldo = saldo.get(sender_id, 0)

    async with bot.conversation(event.chat_id) as conv:
        await event.edit(f"**Input UserName :**\n/cancel Untuk Kembali")
        username_msg = await conv.get_response()
        username = username_msg.raw_text

        if username == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])
            return

        await event.respond(f"**Input Your Expired (days) :**\n/cancel Untuk Kembali")
        exp_msg = await conv.get_response()
        exp_text = exp_msg.raw_text

        if exp_text == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])
            return

        try:
            durasi_hari = int(exp_text)
            harga = hitung_harga(durasi_hari)

            if user_saldo < harga:
                await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
                return

            # Proses pembuatan akun VMess
            limit_ip = "2"
            quota = "200"
            cmd = f'printf "%s\n" "1" "{username}" "{durasi_hari}" "{limit_ip}" "{quota}" "{sender_id}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

            # Potong saldo pengguna
            saldo[sender_id] -= harga
            save_saldo(saldo)

            await event.respond(f"""
✅ Akun VMess berhasil dibuat!
💰 Saldo tersisa: {saldo[sender_id]} 💵
""", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])

        except ValueError:
            await event.respond("❌ Input tidak valid! Pastikan Anda memasukkan angka untuk durasi hari.")
