from kyt import *
import json
import subprocess
import requests

# ID Admin (ganti dengan ID pengguna admin yang sebenarnya)
ADMIN_ID = 7251232303  # Ganti dengan ID admin yang sesuai

# Fungsi untuk memeriksa apakah pengirim adalah admin
def is_admin(sender_id):
    return sender_id == ADMIN_ID

# Load saldo dari file JSON
def load_saldo():
    try:
        with open("saldo.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Simpan saldo ke file JSON
def save_saldo(saldo):
    with open("saldo.json", "w") as f:
        json.dump(saldo, f)

saldo = load_saldo()

# Harga per hari
HARGA_PER_HARI = 200
HARGA_30_HARI = 6000

# Fungsi untuk menghitung harga berdasarkan durasi
def hitung_harga(durasi_hari):
    if durasi_hari == 1:
        return HARGA_PER_HARI
    elif durasi_hari == 30:
        return HARGA_30_HARI
    else:
        # Jika lebih dari 30 hari, hitung berdasarkan harga per hari
        return HARGA_PER_HARI * durasi_hari

# VMESS Main Menu
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        sender_id = event.sender_id
        inline = [
            [Button.inline(" Trial ", "trial7-vmess"),
             Button.inline(" Create ", "create7-vmess"),
             Button.inline(" Login ", "cek7-vmess")]
        ]
        if is_admin(sender_id):  # Cek apakah pengirim adalah admin
            inline.append([
                Button.inline(" Delete ", "delete7-vmess"),
                Button.inline(" Unlock ", "login7-vmess"),
                Button.inline(" Limit ", "limit7-vmess"),
                Button.inline(" Renew", "renew7-vmess"),
                Button.inline(" Restore ", "restore7-vmess"),
                Button.inline(" Akun ", "akun7-vmess")
            ])
        inline.append([Button.inline("‹ BACK ›", "menu")])

        # Mendapatkan informasi tentang server
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        vm = f'cat /etc/xray/config.json | grep "#vmg" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        msg = f"""
🧿───────────────────🧿
          **PANEL MENU VMESS**
🧿──────────────────
─🧿
` Total   :` `{vms.strip()}` __account__
` Host    :` `{DOMAIN}`
` ISP     :` `{z["isp"]}`
` Country :` `{z["country"]}`
🧿───────────────────🧿
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    await vmess_(event)

# Create VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        user_id = str(event.sender_id)
        user_saldo = saldo.get(user_id, 0)

        async with bot.conversation(chat) as user:
            await event.edit(f"""
**Input UserName :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCEL**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**Input Your Expired (days) :**
/cancel Untuk Kembali
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text

            try:
                durasi_hari = int(exp)
                harga = hitung_harga(durasi_hari)

                if user_saldo < harga:
                    await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
                    return

                # Proses pembuatan akun VMess
                limit_ip = "2"
                quota = "200"
                cmd = f'printf "%s\n" "1" "{user}" "{durasi_hari}" "{limit_ip}" "{quota}" | m-vmess | sleep 2 | exit'
                subprocess.check_output(cmd, shell=True)

                # Potong saldo pengguna
                saldo[user_id] -= harga
                save_saldo(saldo)

                await event.respond(f"""
✅ Akun VMess berhasil dibuat!
💰 Saldo tersisa: {saldo[user_id]} 💵
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

            except ValueError:
                await event.respond("❌ Input tidak valid! Pastikan Anda memasukkan angka untuk durasi hari.")
                
    chat = event.chat_id
    sender = await event.get_sender()
    await create_vmess_(event)

# Fungsi lainnya (trial, delete, renew, dll) tetap sama, hanya perlu ditambahkan pengecekan admin seperti di atas.

