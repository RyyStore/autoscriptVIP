from kyt import *
import json
import subprocess
from datetime import datetime

ADMIN_ID = "7251232303"
SALDO_FILE = "saldo.json"
TRIAL_FILE = "trial.json"

def load_saldo():
    try:
        with open(SALDO_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_saldo(saldo):
    with open(SALDO_FILE, "w") as f:
        json.dump(saldo, f)

def load_trial():
    try:
        with open(TRIAL_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_trial(data):
    with open(TRIAL_FILE, "w") as f:
        json.dump(data, f)

def reset_trial():
    trial_data = load_trial()
    today = datetime.now().strftime("%Y-%m-%d")
    if "last_reset" not in trial_data or trial_data["last_reset"] != today:
        trial_data = {"last_reset": today}
        save_trial(trial_data)

saldo = load_saldo()
HARGA_PER_HARI = 200
HARGA_30_HARI = 6000

def hitung_harga(durasi_hari):
    if durasi_hari == 1:
        return HARGA_PER_HARI
    elif durasi_hari == 30:
        return HARGA_30_HARI
    else:
        return HARGA_PER_HARI * durasi_hari

@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        user_id = str(event.sender_id)
        reset_trial()
        trial_data = load_trial()
        trial_count = trial_data.get(user_id, 0)

        if user_id != ADMIN_ID and trial_count >= 7:
            await event.respond("❌ Anda sudah mencapai batas maksimal 7 trial per hari!")
            return

        duration = 30
        cmd = f'printf "%s\n" "2" "{duration}" | m-vmess | sleep 2 | exit'
        subprocess.check_output(cmd, shell=True).decode("utf-8")

        if user_id != ADMIN_ID:
            trial_data[user_id] = trial_count + 1
            save_trial(trial_data)

        await event.respond(
            f"✅ Trial VMess berhasil dibuat!\n🕒 Durasi: {duration} menit\n📌 Anda sudah menggunakan {trial_data.get(user_id, 0)}/7 trial hari ini."
            if user_id != ADMIN_ID
            else "✅ Trial VMess berhasil dibuat!\n🕒 Durasi: 30 menit\n👑 Admin dapat membuat trial tanpa batas."
        )

    await trial_vmess_(event)

@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        user_id = str(event.sender_id)
        user_saldo = saldo.get(user_id, 0)

        async with bot.conversation(event.chat_id) as user:
            await event.edit("**Input UserName :**\n/cancel Untuk Kembali")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            user = (await user).raw_text

        if user == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        async with bot.conversation(event.chat_id) as exp:
            await event.respond("**Input Your Expired (days) :**\n/cancel Untuk Kembali")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            exp = (await exp).raw_text

        try:
            durasi_hari = int(exp)
            harga = hitung_harga(durasi_hari)

            if user_saldo < harga:
                await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
                return

            limit_ip = "2"
            quota = "200"
            cmd = f'printf "%s\n" "1" "{user}" "{durasi_hari}" "{limit_ip}" "{quota}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

            saldo[user_id] -= harga
            save_saldo(saldo)

            await event.respond(f"✅ Akun VMess berhasil dibuat!\n💰 Saldo tersisa: {saldo[user_id]} 💵", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

        except ValueError:
            await event.respond("❌ Input tidak valid! Pastikan Anda memasukkan angka untuk durasi hari.")

    await create_vmess_(event)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline(" Trial ", "trial7-vmess"),
             Button.inline(" Create ", "create7-vmess")],
            [Button.inline("‹ BACK ›", "menu")]
        ]
        msg = f"""
🧿───────────────────🧿
          **PANEL MENU VMESS**
🧿──────────────────
**› Trial** : **7x per hari**
**› Create** : **Berbayar**
**> Harga** : **Perhari 200 Rupiah**
🧿───────────────────🧿
"""
        await event.edit(msg, buttons=inline)

    await vmess_(event)
