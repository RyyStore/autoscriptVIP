from kyt import *
import json

# Load saldo dari file JSON
def load_saldo():
    try:
        with open("saldo.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Simpan saldo ke file JSON
def save_saldo(saldo):
    with open("saldo.json", "w") as f:
        json.dump(saldo, f)

saldo = load_saldo()

# Harga pembuatan akun VMess
HARGA_VMESS = 6000

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**LIST ALL USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        else:
            cmd = f'printf "%s\n" "4" "{user}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    await delete_vmess_(event)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vmess'))
async def renew_vmess(event):
    async def renew_vmess_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**LIST ALL USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**Input Your New Expired (day) :**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    await renew_vmess_(event)

#limit
@bot.on(events.CallbackQuery(data=b'limit7-vmess'))
async def limit_vmess(event):
    async def limit_vmess_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**CHANGE LIMIT USER**
{z}
**Input Your Number :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**Input Your New Limit IP Login :**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            async with bot.conversation(chat) as pw:
                await event.respond(f"""
**Input Your New Quota User :**
""")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» SUCCES CHANGE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    await limit_vmess_(event)

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        user_id = str(event.sender_id)
        user_saldo = saldo.get(user_id, 0)

        if user_saldo < HARGA_VMESS:
            await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
            return

        async with bot.conversation(chat) as user:
            await event.edit(f"""
**Input UserName :**
/cancel Untuk Kembali
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        else:
            # Default limit IP dan quota
            limit_ip = "2"
            quota = "200"

            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**Input Your Expired (day) :**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text

            cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{limit_ip}" "{quota}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)

            # Kurangi saldo pengguna
            saldo[user_id] -= HARGA_VMESS
            save_saldo(saldo)

            await event.respond(f"""
✅ Akun VMess berhasil dibuat!
💰 Saldo tersisa: {saldo[user_id]} 💵
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    await create_vmess_(event)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        async with bot.conversation(chat) as exp:
            await event.edit(f"""
**Input Your Minutes (Hanya Angka) :**
/cancel Untuk Kembali
""")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        per = "/cancel"
        if exp == per:
            await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
        else:
            cmd = f'printf "%s\n" {2} "{exp}" | m-vmess | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
    chat = event.chat_id
    sender = await event.get_sender()
    await trial_vmess_(event)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vmess'))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'bot-cek-ws'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.edit(f"""
**VMESS USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    sender = await event.get_sender()
    await cek_vmess_(event)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
[Button.inline(" Trial ","trial7-vmess"),
Button.inline(" Create ","create7-vmess"),
Button.inline(" Login ","cek7-vmess")],
[Button.inline(" Delete ","delete7-vmess"),
Button.inline(" Unlock ","login7-vmess"),
Button.inline(" Limit ","limit7-vmess")],
[Button.inline(" Renew","renew7-vmess"),
Button.inline(" Restore ","restore7-vmess"),
Button.inline(" Akun ","akun7-vmess")],
[Button.inline("‹ BACK ›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        msg = f"""
🧿───────────────────🧿
          **PANEL MENU VMESS**
🧿───────────────────🧿
` Total   :` `{vms.strip()}` __account__
` Host    :` `{DOMAIN}`
` ISP     :` `{z["isp"]}`
` Country :` `{z["country"]}`
🧿───────────────────🧿
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    await vmess_(event)