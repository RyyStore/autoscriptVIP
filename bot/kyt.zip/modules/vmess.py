from kyt import *
import json
import subprocess
from datetime import datetime

ADMIN_IDS = ["7251232303"]  # Daftar ID Admin
SALDO_FILE = "saldo.json"
TRIAL_FILE = "trial.json"

def load_json(file):
    try:
        with open(file, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_json(file, data):
    with open(file, "w") as f:
        json.dump(data, f)

def reset_trial():
    trial_data = load_json(TRIAL_FILE)
    today = datetime.now().strftime("%Y-%m-%d")
    if "last_reset" not in trial_data or trial_data["last_reset"] != today:
        trial_data = {"last_reset": today}
        save_json(TRIAL_FILE, trial_data)

@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    user_id = str(event.sender_id)
    reset_trial()
    trial_data = load_json(TRIAL_FILE)
    user_trial = trial_data.get(user_id, {"count": 0, "accounts": []})

    if user_id not in ADMIN_IDS and user_trial["count"] >= 7:
        await event.respond("❌ Anda sudah mencapai batas maksimal 7 trial per hari!")
        return

    duration = 30
    cmd = f'printf "%s\n" "2" "{duration}" "{user_id}" | m-vmess | sleep 2 | exit'
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8").strip()
    except subprocess.CalledProcessError as e:
        await event.respond(f"❌ Gagal membuat trial:\n{e.output.decode()}")
        return

    user_trial["count"] += 1
    user_trial["accounts"].append(output)
    trial_data[user_id] = user_trial
    save_json(TRIAL_FILE, trial_data)

    await event.respond(f"✅ Trial VMess berhasil dibuat!\n🕒 Durasi: {duration} menit\n📌 Anda sudah menggunakan {user_trial['count']}/7 trial hari ini.\n\n🔗 **Detail akun:**\n{output}")

@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    user_id = str(event.sender_id)
    saldo = load_json(SALDO_FILE)
    user_saldo = saldo.get(user_id, 0)

    async with bot.conversation(event.chat_id) as conv:
        await event.respond("**Input Username:**\n/cancel untuk kembali")
        username = await conv.get_response()
        if username.text == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

        await event.respond("**Input Durasi (hari):**\n/cancel untuk kembali")
        exp = await conv.get_response()
        if exp.text == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

    try:
        durasi_hari = int(exp.text)
        harga = 200 * durasi_hari  # Harga per hari

        if user_saldo < harga:
            await event.respond("❌ Saldo tidak cukup! Silakan topup terlebih dahulu.")
            return

        cmd = f'printf "%s\n" "1" "{username.text}" "{durasi_hari}" "{user_id}" | m-vmess | sleep 2 | exit'
        try:
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8").strip()
        except subprocess.CalledProcessError as e:
            await event.respond(f"❌ Gagal membuat akun:\n{e.output.decode()}")
            return

        saldo[user_id] -= harga
        save_json(SALDO_FILE, saldo)

        await event.respond(f"✅ Akun VMess berhasil dibuat!\n💰 Saldo tersisa: {saldo[user_id]} 💵\n\n🔗 **Detail akun:**\n{output}")

    except ValueError:
        await event.respond("❌ Input tidak valid! Pastikan Anda memasukkan angka.")

@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
    user_id = str(event.sender_id)

    if user_id not in ADMIN_IDS:
        await event.respond("❌ Anda tidak memiliki akses untuk menghapus akun VMess!")
        return

    async with bot.conversation(event.chat_id) as conv:
        cmd2 = "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '"
        x = subprocess.check_output(cmd2, shell=True).decode("ascii")
        await event.respond(f"**LIST ALL USER**\n{x}\n\n**Input Your Number:**\n/cancel untuk kembali")

        user_input = await conv.get_response()
        if user_input.text == "/cancel":
            await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            return

    cmd = f'printf "%s\n" "4" "{user_input.text}" | m-vmess | sleep 2 | exit'
    subprocess.check_output(cmd, shell=True)

    await event.respond("✅ Akun VMess berhasil dihapus!", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    user_id = str(event.sender_id)
    is_admin = user_id in ADMIN_IDS

    inline = [
        [Button.inline(" Trial ", "trial7-vmess"), Button.inline(" Create ", "create7-vmess")]
    ]

    if is_admin:
        inline.append([Button.inline(" Delete ", "delete7-vmess")])

    inline.append([Button.inline("‹ BACK ›", "menu")])

    msg = f"""
🧿───────────────────🧿
          **PANEL MENU VMESS**
🧿──────────────────
**› Trial** : **7x per hari**
**› Create** : **Berbayar**
{"**› Delete** : **Admin Only**" if is_admin else ""}
🧿───────────────────🧿
"""
    await event.respond(msg, buttons=inline)
